-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 02/06/2025 às 11:22
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `gerenciador_de_cantinas`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nomeempresa` varchar(100) NOT NULL,
  `localizacao` varchar(255) NOT NULL,
  `horadeabertura` time NOT NULL,
  `horadefechamento` time NOT NULL,
  `nif` varchar(20) NOT NULL,
  `numerodecelular` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `data_cadastro` datetime DEFAULT current_timestamp(),
  `ativo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nomeempresa`, `localizacao`, `horadeabertura`, `horadefechamento`, `nif`, `numerodecelular`, `email`, `senha`, `data_cadastro`, `ativo`) VALUES
(1, 'Ecommerces', 'cAZENGA hoji ya henda rua da liberdade', '23:00:00', '20:00:00', '243328878', '986767679', 'bernardobranco53@gmail.com', '$2y$10$3fzUFagLWjoLjg5H07VFQ.eXVxFC2sJC971aVTLnxCTXPswcrXr.e', '2025-06-01 14:42:55', 1),
(2, 'TrendShop', 'online', '10:02:00', '10:00:00', '873083837', '943705362', 'gracilianahonjo@gmail.com', '$2y$10$Cq0TiUs8M.tr5B8lhFnL8eOkUl.IXdHDzRHIKetFPs1yHBlpfH20O', '2025-06-01 17:57:07', 1),
(3, 'EcommerceR', 'cAZENGA hoji ya henda rua da liberdade', '01:03:00', '21:23:00', '838687433', '943705362', 'gracilianahonjo1@gmail.com', '$2y$10$SoCBgVJYZLsRWIfjPXT5zOOyhNy3KoNC/xbi2KaeKPBV92UL9wg0S', '2025-06-02 04:51:30', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `nomedoproduto` varchar(100) NOT NULL,
  `precodoproduto` decimal(10,2) NOT NULL,
  `descricaodoproduto` text DEFAULT NULL,
  `imagemdoproduto` varchar(255) DEFAULT NULL,
  `disponiveis` tinyint(1) DEFAULT 1,
  `data_cadastro` datetime DEFAULT current_timestamp(),
  `quantidade` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nif` (`nif`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `produtos`
--
ALTER TABLE `produtos`
  ADD CONSTRAINT `produtos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
