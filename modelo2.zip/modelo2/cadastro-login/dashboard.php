<?php
session_start();
require 'config.php';

if (!isset($_SESSION['cliente_id'])) {
    header("Location: i-sessao.php");
    exit();
}

// Buscar informações do cliente
$stmt = $pdo->prepare("SELECT * FROM clientes WHERE id = ?");
$stmt->execute([$_SESSION['cliente_id']]);
$cliente = $stmt->fetch();

if (!$cliente) {
    session_destroy();
    header("Location: i-sessao.php");
    exit();
}

// Buscar produtos da cantina
$stmt = $pdo->prepare("SELECT * FROM produtos WHERE cliente_id = ? ORDER BY data_cadastro DESC");
$stmt->execute([$_SESSION['cliente_id']]);
$produtos = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - <?= htmlspecialchars($cliente['nomeempresa']) ?></title>
    <!-- Seus estilos aqui -->
</head>
<body>
    <h1>Bem-vindo, <?= htmlspecialchars($cliente['nomeempresa']) ?></h1>
    
    <section>
        <h2>Seus Produtos</h2>
        <?php if (count($produtos) > 0): ?>
            <ul>
                <?php foreach ($produtos as $produto): ?>
                    <li>
                        <h3><?= htmlspecialchars($produto['nomedoproduto']) ?></h3>
                        <p>R$ <?= number_format($produto['precodoproduto'], 2, ',', '.') ?></p>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>Você ainda não cadastrou nenhum produto.</p>
        <?php endif; ?>
    </section>
    
    <a href="logout.php">Sair</a>
</body>
</html>