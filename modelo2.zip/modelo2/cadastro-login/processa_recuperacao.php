<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nomeEmpresa = trim($_POST['nomeEmpresa']);
    $nif = preg_replace('/\D/', '', $_POST['nif']);
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $celular = isset($_POST['celular']) ? preg_replace('/\D/', '', $_POST['celular']) : null;
    
    // Verificar se a conta existe
    $sql = "SELECT id, email, numerodecelular FROM clientes WHERE nomeempresa = ? AND nif = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nomeEmpresa, $nif]);
    $cliente = $stmt->fetch();
    
    if (!$cliente) {
        die("Conta não encontrada. Verifique os dados informados.");
    }
    
    // Gerar token de recuperação
    $token = bin2hex(random_bytes(32));
    $expiracao = date('Y-m-d H:i:s', strtotime('+1 hour'));
    
    // Salvar token no banco
    $stmt = $pdo->prepare("UPDATE clientes SET token_recuperacao = ?, token_expiracao = ? WHERE id = ?");
    $stmt->execute([$token, $expiracao, $cliente['id']]);
    
    // Enviar email/SMS com o link de recuperação
    $link = "https://seusite.com/redefinir_senha.php?token=$token";
    
    // Aqui você implementaria o envio real por email/SMS
    // Esta é apenas uma simulação
    $destino = $email ? $email : $cliente['numerodecelular'];
    $mensagem = "Recebemos uma solicitação para redefinir sua senha. Clique no link abaixo:\n\n$link\n\nO link expira em 1 hora.";
    
    // Simulação - na prática, use uma biblioteca de email ou serviço de SMS
    mail($destino, "Redefinição de Senha", $mensagem);
    
    header("Location: recuperacao_enviada.php");
    exit();
} else {
    header("Location: recuperacao.php");
    exit();
}
?>