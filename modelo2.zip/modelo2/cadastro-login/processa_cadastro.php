<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Receber e validar dados
    $nomeEmpresa = trim($_POST['nomeEmpresa']);
    $localizacao = trim($_POST['localizacao']);
    $abertura = $_POST['abertura'];
    $fechamento = $_POST['fechamento'];
    $nif = preg_replace('/\D/', '', $_POST['nif']);
    $celular = preg_replace('/\D/', '', $_POST['celular']);
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $senha = $_POST['senha'];
    
    // Verificar se email ou NIF já existem
    $stmt = $pdo->prepare("SELECT id FROM clientes WHERE email = ? OR nif = ?");
    $stmt->execute([$email, $nif]);
    if ($stmt->rowCount() > 0) {
        die("Email ou NIF já cadastrados.");
    }
    
    // Hash da senha
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
    
    // Inserir no banco
    $stmt = $pdo->prepare("INSERT INTO clientes (nomeempresa, localizacao, horadeabertura, horadefechamento, nif, numerodecelular, email, senha) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    try {
        $stmt->execute([$nomeEmpresa, $localizacao, $abertura, $fechamento, $nif, $celular, $email, $senhaHash]);
        
        // Redirecionar para página de sucesso
        header("Location: cadastro_sucesso.php");
        exit();
    } catch (PDOException $e) {
        die("Erro ao cadastrar: " . $e->getMessage());
    }
} else {
    header("Location: cadastro.php");
    exit();
}
?>