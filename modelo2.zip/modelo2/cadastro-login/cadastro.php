<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro de Cantina</title>
 <style>
   
    :root {
      --primary-color:#077aa8;
      --primary-hover:#54d1e7;
      --secondary-color: #6c757d;
      --success-color: #28a745;
      --error-color: #dc3545;
      --light-gray: #f8f9fa;
      --border-color: #ced4da;
      --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
      min-height: 100vh;
      padding: 40px 20px;
      color: #333;
      line-height: 1.6;
    }
    
    .container {
      max-width: 600px;
      margin: 0 auto;
      animation: fadeIn 0.5s ease-in-out;
    }
    
    .back-button {
      display: inline-flex;
      align-items: center;
      margin-bottom: 20px;
      color: var(--primary-color);
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s ease;
    }
       .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #ff69b4;
            text-decoration: none;
        }
    
    .back-button:hover {
      color: var(--primary-hover);
      transform: translateX(-3px);
    }
    
    .back-button svg {
      margin-right: 8px;
    }
    
    .card {
      background: white;
      border-radius: 12px;
      box-shadow: var(--box-shadow);
      overflow: hidden;
      transition: transform 0.3s ease;
    }
    
    .card:hover {
      transform: translateY(-5px);
    }
    
    .card-header {
      background: var(--primary-color);
      color: white;
      padding: 20px;
      text-align: center;
    }
    
    .card-header h2 {
      font-size: 1.8rem;
      margin: 0;
    }
    
    .card-body {
      padding: 30px;
    }
    
    .form-group {
      margin-bottom: 20px;
      position: relative;
    }
    
    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: #495057;
    }
    
    .required-field::after {
      content: " *";
      color: var(--error-color);
    }
    
    input {
      width: 100%;
      padding: 12px 15px;
      border: 2px solid var(--border-color);
      border-radius: 8px;
      font-size: 1rem;
      transition: all 0.3s;
    }
    
    input:focus {
      border-color: var(--primary-color);
      outline: none;
      box-shadow: 0 0 0 3px rgba(255, 105, 180, 0.2);
    }
    
    .input-icon {
      position: relative;
    }
    
    .input-icon input {
      padding-left: 40px;
    }
    
    .input-icon i {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--secondary-color);
    }
    
    .message {
      font-size: 0.85rem;
      margin-top: 6px;
      display: flex;
      align-items: center;
    }
    
    .message.error {
      color: var(--error-color);
    }
    
    .message.success {
      color: var(--success-color);
    }
    
    .message i {
      margin-right: 5px;
      font-size: 1rem;
    }
    
    .btn {
      display: inline-block;
      background: var(--primary-color);
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      transition: all 0.3s;
      width: 100%;
      margin-top: 10px;
    }
    
    .btn:hover {
      background: var(--primary-hover);
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    
    .btn:active {
      transform: translateY(0);
    }
    
    .time-inputs {
      display: flex;
      gap: 15px;
    }
    
    .time-inputs .form-group {
      flex: 1;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    @media (max-width: 576px) {
      .card-body {
        padding: 20px;
      }
      
      .time-inputs {
        flex-direction: column;
        gap: 0;
      }
    }
  
 </style>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
  <div class="container">
    <a href="../html/index.php" class="back-link">← Voltar para a página inicial</a> <br>
    <a href="i-sessao.php" class="back-button">
      <i class="fas fa-arrow-left"></i>
      Já tenho uma conta - Iniciar sessão
    </a>
    
    <div class="card">
      <div class="card-header">
        <h2>Cadastro de Cantina</h2>
      </div>
      <!-- id formulario mude com cadastroForm  -->
      <div class="card-body">
        <form id="cadastroForm"  action="processa_cadastro.php" method="post" >
          <div class="form-group">
            <label for="nomeEmpresa" class="required-field">Nome da Empresa</label>
            <div class="input-icon">
              <i class="fas fa-store"></i>
              <input type="text" id="nomeEmpresa"  name="nomeEmpresa" placeholder="Digite o nome da sua empresa">
            </div>
            <div id="mensagemNome" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="localizacao" class="required-field">Localização</label>
            <div class="input-icon">
              <i class="fas fa-map-marker-alt"></i>
              <input type="text" id="localizacao" name="localizacao"  placeholder="Onde sua cantina está localizada?">
            </div>
          </div>
          
          <div class="time-inputs">
            <div class="form-group">
              <label for="abertura" class="required-field">Hora de Abertura</label>
              <div class="input-icon">
                <i class="fas fa-door-open"></i>
                <input type="time" id="abertura" name="abertura">
              </div>
            </div>
            
            <div class="form-group">
              <label for="fechamento" class="required-field">Hora de Fechamento</label>
              <div class="input-icon">
                <i class="fas fa-door-closed"></i>
                <input type="time" id="fechamento" name="fechamento">
              </div>
            </div>
          </div>
          
          <div class="form-group">
            <label for="nif" class="required-field">NIF</label>
            <div class="input-icon">
              <i class="fas fa-id-card"></i>
              <input type="number" id="nif" name="nif" placeholder="Digite o NIF da empresa">
            </div>
            <div id="mensagemNif" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="celular" class="required-field">Número de Celular</label>
            <div class="input-icon">
              <i class="fas fa-mobile-alt"></i>
              <input type="tel" id="celular" name="celular" placeholder="90000-0000" >
            </div>
            <div id="mensagemCelular" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="email" class="required-field">Email</label>
            <div class="input-icon">
              <i class="fas fa-envelope"></i>
              <input type="email" id="email" name="email" placeholder="seu@email.com">
            </div>
            <div id="mensagemEmail" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="senha" class="required-field">Senha</label>
            <div class="input-icon">
              <i class="fas fa-lock"></i>
              <input type="password" id="senha" name="senha" placeholder="Crie uma senha segura">
            </div>
            <div id="mensagemSenha" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="confirmarSenha" class="required-field">Confirmação de Senha</label>
            <div class="input-icon">
              <i class="fas fa-lock"></i>
              <input type="password" id="confirmarSenha" name="confirmarSenha" placeholder="Confirme sua senha">
            </div>
            <div id="mensagemConfirmar" class="message"></div>
          </div>
          
          <button type="submit" class="btn">
            <i class="fas fa-check-circle"></i> Confirmar Cadastro
          </button>
        </form>
      </div>
    </div>
  </div>

 <script>
      document.addEventListener('DOMContentLoaded', function() {
      const form = document.getElementById('formulario');
      
      // Format phone number
    document.getElementById('celular').addEventListener('input', function(e) {
      let value = e.target.value.replace(/\D/g, ''); // Remove tudo que não for número

      // Divide em grupos de até 3 dígitos e junta com espaço
      value = value.match(/.{1,3}/g)?.join(' ') || '';

      e.target.value = value;
    });

    
      function validarNome(nome) {
        const regex = /^[A-Z][a-zA-Z_]{5,}$/;
        if (!regex.test(nome)) {
          return {valid: false, message: "O nome deve começar com maiúscula, ter no mínimo 6 letras, sem espaços ou números."};
        }
        return {valid: true, message: "Nome válido!"};
      }

      function validarNumero(numero) {
        const digits = numero.replace(/\D/g, '');
        const regex = /^\d{9}$/;
        if (!regex.test(digits)) {
          return {valid: false, message: "Deve conter exatamente 9 dígitos numéricos."};
        }
        return {valid: true, message: "Número válido!"};
      }

      function validarEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!regex.test(email)) {
          return {valid: false, message: "Email inválido."};
        }
        return {valid: true, message: "Email válido!"};
      }

      function validarSenha(senha) {
        const regex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#\$%\^&\*\(\)_\+\-=\[\]{};':"\\|,.<>\/?]).{8,18}$/;
        if (!regex.test(senha)) {
          return {valid: false, message: "Deve ter de 8 a 18 caracteres, com letras, números e símbolos."};
        }
        return {valid: true, message: "Senha forte!"};
      }

      function exibirMensagem(idCampo, validation) {
        const elemento = document.getElementById(idCampo);
        elemento.textContent = validation.message;
        elemento.className = validation.valid ? "message success" : "message error";
        
        // Adiciona ícone
        const icon = validation.valid ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-exclamation-circle"></i>';
        elemento.innerHTML = icon + ' ' + validation.message;
      }

      // Validação em tempo real
      document.getElementById('nomeEmpresa').addEventListener('input', e => {
        exibirMensagem('mensagemNome', validarNome(e.target.value.trim()));
      });

      document.getElementById('nif').addEventListener('input', e => {
        exibirMensagem('mensagemNif', validarNumero(e.target.value.trim()));
      });

      document.getElementById('celular').addEventListener('input', e => {
        exibirMensagem('mensagemCelular', validarNumero(e.target.value.replace(/\D/g, '')));
      });

      document.getElementById('email').addEventListener('input', e => {
        exibirMensagem('mensagemEmail', validarEmail(e.target.value.trim()));
      });

      document.getElementById('senha').addEventListener('input', e => {
        const senha = e.target.value;
        exibirMensagem('mensagemSenha', validarSenha(senha));

        // Verifica também a confirmação
        const confirmar = document.getElementById('confirmarSenha').value;
        if (confirmar) {
          const validation = {
            valid: confirmar === senha,
            message: confirmar === senha ? "Senhas coincidem!" : "As senhas não coincidem."
          };
          exibirMensagem('mensagemConfirmar', validation);
        }
      });

      document.getElementById('confirmarSenha').addEventListener('input', e => {
        const senha = document.getElementById('senha').value;
        const confirmar = e.target.value;
        const validation = {
          valid: confirmar === senha,
          message: confirmar === senha ? "Senhas coincidem!" : "As senhas não coincidem."
        };
        exibirMensagem('mensagemConfirmar', validation);
      });

      form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validar todos os campos
           const nomeVal = validarNome(document.getElementById('nomeEmpresa').value.trim());
    const nifVal = validarNumero(document.getElementById('nif').value.trim());
    const celVal = validarNumero(document.getElementById('celular').value.replace(/\D/g, ''));
    const emailVal = validarEmail(document.getElementById('email').value.trim());
    const senhaVal = validarSenha(document.getElementById('senha').value);
    const confirmarVal = document.getElementById('confirmarSenha').value === document.getElementById('senha').value;


    const abertura = document.getElementById('abertura').value;
    const fechamento = document.getElementById('fechamento').value;
    const localizacao = document.getElementById('localizacao').value.trim();

        // Verificar campos obrigatórios
      if (!abertura || !fechamento || !localizacao || !nomeVal.valid || !nifVal.valid || 
        !celVal.valid || !emailVal.valid || !senhaVal.valid || !confirmarVal) {
        e.preventDefault();



        // Verificar horários
        if (!abertura || !fechamento) {
          alert("Por favor, defina os horários de funcionamento.");
          return;
        }
        
        if (!localizacao) {
          alert("Por favor, informe a localização da cantina.");
          return;
        }
        
        // Exibir mensagens para campos inválidos
        if (!nomeVal.valid) exibirMensagem('mensagemNome', nomeVal);
        if (!nifVal.valid) exibirMensagem('mensagemNif', nifVal);
        if (!celVal.valid) exibirMensagem('mensagemCelular', celVal);
        if (!emailVal.valid) exibirMensagem('mensagemEmail', emailVal);
        if (!senhaVal.valid) exibirMensagem('mensagemSenha', senhaVal);
        
        const confirmValidation = {
          valid: confirmarVal,
          message: confirmarVal ? "Senhas coincidem!" : "As senhas não coincidem."
        };
        exibirMensagem('mensagemConfirmar', confirmValidation);
        
        if (nomeVal.valid && nifVal.valid && celVal.valid && 
            emailVal.valid && senhaVal.valid && confirmarVal) {
          // Simular envio (substitua por AJAX na implementação real)
          setTimeout(() => {
            alert("Cadastro realizado com sucesso!\n\nEm breve você receberá um email de confirmação.");
            form.reset();
            document.querySelectorAll(".message").forEach(el => el.textContent = "");
          }, 500);
        } else {
          // Rolagem suave para o primeiro erro
          const firstError = document.querySelector(".message.error");
          if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }
        const firstError = document.querySelector(".message.error");
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    // Se tudo estiver válido, o formulário será submetido normalmente
});
      });
  


         // Verifica se a página atual é cadastro.php ou i-sessao.php
        if (window.location.pathname.includes('cadastro.php') || 
            window.location.pathname.includes('i-sessao.php')) {
            
            // Armazena a página atual no sessionStorage
            sessionStorage.setItem('shouldRedirectToIndex', 'true');
        }

        // Função para manipular o evento de voltar
        function handleBackButton(e) {
            if (sessionStorage.getItem('shouldRedirectToIndex') === 'true') {
                // Previne o comportamento padrão do botão voltar
                e.preventDefault();
                
                // Remove o item do sessionStorage
                sessionStorage.removeItem('shouldRedirectToIndex');
                
                // Redireciona para index.php
                window.location.href = '../html/index.php';
            }
        }

        // Adiciona o event listener para o evento popstate
        window.addEventListener('popstate', handleBackButton);

        // Adiciona um estado ao histórico para garantir que o evento popstate seja disparado
        history.pushState(null, null, window.location.href);

        // Adiciona um link de voltar manual que também usa a mesma lógica
        document.querySelector('.back-link').addEventListener('click', function(e) {
            e.preventDefault();
            sessionStorage.removeItem('shouldRedirectToIndex');
            window.location.href = '../html/index.php';
        });
 </script>
</body>
</html>