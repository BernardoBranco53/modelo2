<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro de Cantina</title>
 <link rel="stylesheet" href="cadastro.css">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
  <div class="container">
    <a href="../html/index.php" class="back-link">← Voltar para a página inicial</a> <br>
    <a href="i-sessao.php" class="back-button">
      <i class="fas fa-arrow-left"></i>
      Já tenho uma conta - Iniciar sessão
    </a>
    
    <div class="card">
      <div class="card-header">
        <h2>Cadastro de Cantina</h2>
      </div>
      <!-- id formulario mude com cadastroForm  -->
      <div class="card-body">
        <form id="cadastroForm"  action="processa_cadastro.php" method="post" >
          <div class="form-group">
            <label for="nomeEmpresa" class="required-field">Nome da Empresa</label>
            <div class="input-icon">
              <i class="fas fa-store"></i>
              <input type="text" id="nomeEmpresa" placeholder="Digite o nome da sua empresa">
            </div>
            <div id="mensagemNome" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="localizacao" class="required-field">Localização</label>
            <div class="input-icon">
              <i class="fas fa-map-marker-alt"></i>
              <input type="text" id="localizacao" placeholder="Onde sua cantina está localizada?">
            </div>
          </div>
          
          <div class="time-inputs">
            <div class="form-group">
              <label for="abertura" class="required-field">Hora de Abertura</label>
              <div class="input-icon">
                <i class="fas fa-door-open"></i>
                <input type="time" id="abertura">
              </div>
            </div>
            
            <div class="form-group">
              <label for="fechamento" class="required-field">Hora de Fechamento</label>
              <div class="input-icon">
                <i class="fas fa-door-closed"></i>
                <input type="time" id="fechamento">
              </div>
            </div>
          </div>
          
          <div class="form-group">
            <label for="nif" class="required-field">NIF</label>
            <div class="input-icon">
              <i class="fas fa-id-card"></i>
              <input type="number" id="nif" placeholder="Digite o NIF da empresa">
            </div>
            <div id="mensagemNif" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="celular" class="required-field">Número de Celular</label>
            <div class="input-icon">
              <i class="fas fa-mobile-alt"></i>
              <input type="text" id="celular" placeholder="(00) 00000-0000">
            </div>
            <div id="mensagemCelular" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="email" class="required-field">Email</label>
            <div class="input-icon">
              <i class="fas fa-envelope"></i>
              <input type="email" id="email" placeholder="seu@email.com">
            </div>
            <div id="mensagemEmail" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="senha" class="required-field">Senha</label>
            <div class="input-icon">
              <i class="fas fa-lock"></i>
              <input type="password" id="senha" placeholder="Crie uma senha segura">
            </div>
            <div id="mensagemSenha" class="message"></div>
          </div>
          
          <div class="form-group">
            <label for="confirmarSenha" class="required-field">Confirmação de Senha</label>
            <div class="input-icon">
              <i class="fas fa-lock"></i>
              <input type="password" id="confirmarSenha" placeholder="Confirme sua senha">
            </div>
            <div id="mensagemConfirmar" class="message"></div>
          </div>
          
          <button type="submit" class="btn">
            <i class="fas fa-check-circle"></i> Confirmar Cadastro
          </button>
        </form>
      </div>
    </div>
  </div>

 <script src="cadastro.js"></script>
</body>
</html>