<?php
session_start();
require 'config.php';

// Verificar se o usuário já está logado
if (isset($_SESSION['cliente_id'])) {
    header("Location: ../usuario/painel_cliente.php");
    exit();
}

// Inicializar a variável $erro
$erro = isset($_GET['erro']) ? (int)$_GET['erro'] : 0;
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Gerenciador de Cantinas</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    
   
    .alert-error {
      background-color: #f8d7da;
      color: var(--error-color);
      padding: 10px 15px;
      border-radius: 5px;
      margin-bottom: 20px;
      border: 1px solid #f5c6cb;
      display: <?= $erro ? 'block' : 'none' ?>;
    }
     :root {
      --primary-color:#077aa8;
      --primary-hover:#54d1e7;
      --secondary-color: #6c757d;
      --light-gray: #f8f9fa;
      --border-color: #ced4da;
      --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      --text-color: #495057;
       --error-color: #dc3545;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: var(--text-color);
      line-height: 1.6;
      padding: 20px;
    }
    
    .login-container {
      max-width: 450px;
      width: 100%;
      animation: fadeIn 0.5s ease-in-out;
    }
    
    .login-card {
      background: white;
      border-radius: 12px;
      box-shadow: var(--box-shadow);
      overflow: hidden;
      transition: transform 0.3s ease;
    }
    
    .login-card:hover {
      transform: translateY(-5px);
    }
    
    .card-header {
      background: var(--primary-color);
      color: white;
      padding: 25px;
      text-align: center;
    }
    
    .card-header h2 {
      font-size: 1.8rem;
      margin: 0;
    }
    
    .card-body {
      padding: 30px;
    }
    
    .form-group {
      margin-bottom: 25px;
      position: relative;
    }
    
    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
    }
    
    .input-icon {
      position: relative;
    }
    
    .input-icon input {
      width: 100%;
      padding: 12px 15px 12px 40px;
      border: 2px solid var(--border-color);
      border-radius: 8px;
      font-size: 1rem;
      transition: all 0.3s;
    }
    
    .input-icon input:focus {
      border-color: var(--primary-color);
      outline: none;
      box-shadow: 0 0 0 3px rgba(255, 105, 180, 0.2);
    }
    
    .input-icon i {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--secondary-color);
    }
    
    /* Estilo para o botão de mostrar senha */
    .toggle-password {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--secondary-color);
      cursor: pointer;
      z-index: 2;
    }
    
    .toggle-password:hover {
      color: var(--primary-color);
    }
    
    .btn {
      display: block;
      width: 100%;
      background: var(--primary-color);
      color: white;
      border: none;
      padding: 14px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      transition: all 0.3s;
      margin-top: 10px;
    }
    
    .btn:hover {
      background: var(--primary-hover);
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    
    .btn:active {
      transform: translateY(0);
    }
    
    .link-container {
      text-align: center;
      margin-top: 20px;
      font-size: 0.95rem;
    }
    
    .link-container a {
      color: var(--primary-color);
      text-decoration: none;
      font-weight: 600;
      transition: all 0.3s;
    }
    
    .link-container a:hover {
      color: var(--primary-hover);
      text-decoration: underline;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    @media (max-width: 576px) {
      .card-body {
        padding: 25px;
      }
      
      .card-header {
        padding: 20px;
      }
    } 
  </style>
</head>
<body>
  <div class="login-container">
    <div class="login-card">
      <div class="card-header">
        <h2>Login</h2>
      </div>
      
      <div class="card-body">
        
        <!-- Mensagem de erro -->
        <?php if ($erro): ?>
          <div class="alert-error">
            <i class="fas fa-exclamation-circle"></i> Email ou senha incorretos. Tente novamente.
          </div>
        <?php endif; ?>
        
        <form action="processa_login.php" method="post">
          <div class="form-group">
            <label for="email">Email</label>
            <div class="input-icon">
              <i class="fas fa-envelope"></i>
              <input type="email" id="email" name="email" placeholder="seu@email.com" required>
            </div>
          </div>
          
          <div class="form-group">
            <label for="senha">Senha</label>
            <div class="input-icon">
              <i class="fas fa-lock"></i>
              <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>
              
            </div>
          </div>
          
          <button type="submit" class="btn">
            <i class="fas fa-sign-in-alt"></i> Entrar
          </button>
          
          <div class="link-container">
            Não tem uma conta? <a href="cadastro.php">Cadastre-se</a>
          </div>
          
          <div class="link-container">
            <a href="esqueci-senha.php">Esqueceu sua senha?</a> <br>
    <a href="../html/index.php" class="back-link">← Voltar para a página inicial</a> 
          </div>
        </form>
      </div>
    </div>
  </div>

 <script>
   
      document.addEventListener('DOMContentLoaded', function() {
      const togglePassword = document.getElementById('togglePassword');
      const senhaInput = document.getElementById('senha');
      
      togglePassword.addEventListener('click', function() {
        const type = senhaInput.getAttribute('type') === 'password' ? 'text' : 'password';
        senhaInput.setAttribute('type', type);
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
      });
    });
 document.addEventListener('DOMContentLoaded', function() {
      // Função para mostrar/ocultar senha
      const togglePassword = document.getElementById('togglePassword');
      const senhaInput = document.getElementById('senha');
      
      togglePassword.addEventListener('click', function() {
        // Alternar entre type password e text
        const type = senhaInput.getAttribute('type') === 'password' ? 'text' : 'password';
        senhaInput.setAttribute('type', type);
        
        // Alternar o ícone do olho
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
      });
      
      // Validação do formulário
      const form = document.querySelector('form');
      
      form.addEventListener('submit', function(e) {
        const email = document.getElementById('email').value;
        const senha = document.getElementById('senha').value;
        
        if (!email || !senha) {
          e.preventDefault();
          alert('Por favor, preencha todos os campos.');
          return;
        }
        
        // Validação simples de email
        if (!email.includes('@') || !email.includes('.')) {
          e.preventDefault();
          alert('Por favor, insira um email válido.');
          return;
        }
        
        // Validação simples de senha
        if (senha.length < 6) {
          e.preventDefault();
          alert('A senha deve ter pelo menos 6 caracteres.');
          return;
        }
      });
      
      // Efeito hover nos cards
      const cards = document.querySelectorAll('.login-card');
      cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
          card.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', () => {
          card.style.transform = 'translateY(0)';
        });
      });
    });

   
 </script>
</body>
</html>