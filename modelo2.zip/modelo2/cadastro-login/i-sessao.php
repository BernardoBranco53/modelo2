<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro</title>
    <link rel="stylesheet" href="i-sessao.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <?php if ($erro): ?>
<div class="alert alert-danger">
    Email ou senha incorretos. Tente novamente.
</div>
<?php endif; ?>
  <div class="login-container">
    <div class="login-card">
      <div class="card-header">
        <h2>Login</h2>
      </div>
      
      <div class="card-body">
        <form  action="processa_login.php" method="post">
          <div class="form-group">
            <label for="email">Email</label>
            <div class="input-icon">
              <i class="fas fa-envelope"></i>
              <input type="email" id="email" name="email" placeholder="Digite seu email" required>
            </div>
          </div>
          
          <div class="form-group">
            <label for="senha">Senha</label>
            <div class="input-icon">
              <i class="fas fa-lock"></i>
              <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>
            </div>
          </div>
          
          <button type="submit" class="btn">
            <i class="fas fa-sign-in-alt"></i> Entrar
          </button>
          
          <div class="link-container">
            esqueci minha senha? <a href="Esquecisenha/esqueci-senha.php">Recuperar Senha</a><br>
            Não tem uma conta? <a href="cadastro.php">Cadastre-se</a><br>
              <a href="../html/index.php">← inicio</a>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="i-sessao.js"></script>
</body>
</html>