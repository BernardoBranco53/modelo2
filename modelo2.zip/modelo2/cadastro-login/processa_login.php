<?php
require 'config.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $senha = $_POST['senha'];
    
    if (!$email) {
        die("Email inválido.");
    }
    
    // Buscar usuário
    $stmt = $pdo->prepare("SELECT * FROM clientes WHERE email = ?");
    $stmt->execute([$email]);
    $cliente = $stmt->fetch();
    
    if ($cliente && password_verify($senha, $cliente['senha'])) {
        // Login bem-sucedido
        $_SESSION['cliente_id'] = $cliente['id'];
        $_SESSION['cliente_nome'] = $cliente['nomeempresa'];
        
        header("Location: dashboard.php");
        exit();
    } else {
        // Login falhou
        header("Location: i-sessao.php?erro=1");
        exit();
    }
} else {
    header("Location: i-sessao.php");
    exit();
}
?>