<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recuperação de Conta</title>
  <style>
    :root {
   --primary-color:#077aa8;
      --primary-hover:#54d1e7;
      --secondary-color: #6c757d;
      --light-gray: #f8f9fa;
      --border-color: #ced4da;
      --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      --text-color: #495057;
      --error-color: #dc3545;
      --success-color: #28a745;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: var(--text-color);
      line-height: 1.6;
      padding: 20px;
    }
    
    .recovery-container {
      max-width: 500px;
      width: 100%;
      animation: fadeIn 0.5s ease-in-out;
    }
    
    .recovery-card {
      background: white;
      border-radius: 12px;
      box-shadow: var(--box-shadow);
      overflow: hidden;
      transition: transform 0.3s ease;
    }
    
    .recovery-card:hover {
      transform: translateY(-5px);
    }
    
    .card-header {
      background: var(--primary-color);
      color: white;
      padding: 25px;
      text-align: center;
    }
    
    .card-header h2 {
      font-size: 1.8rem;
      margin: 0;
    }
    
    .card-body {
      padding: 30px;
    }
    
    .form-group {
      margin-bottom: 25px;
      position: relative;
    }
    
    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
    }
    
    .required-field::after {
      content: " *";
      color: var(--error-color);
    }
    
    .input-icon {
      position: relative;
    }
    
    .input-icon input, 
    .input-icon select {
      width: 100%;
      padding: 12px 15px 12px 40px;
      border: 2px solid var(--border-color);
      border-radius: 8px;
      font-size: 1rem;
      transition: all 0.3s;
    }
    
    .input-icon input:focus,
    .input-icon select:focus {
      border-color: var(--primary-color);
      outline: none;
      box-shadow: 0 0 0 3px rgba(255, 105, 180, 0.2);
    }
    
    .input-icon i {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--secondary-color);
    }
    
    .radio-group {
      display: flex;
      gap: 15px;
      margin-bottom: 15px;
    }
    
    .radio-option {
      display: flex;
      align-items: center;
    }
    
    .radio-option input {
      margin-right: 8px;
    }
    
    .message {
      font-size: 0.85rem;
      margin-top: 6px;
      display: flex;
      align-items: center;
    }
    
    .message.error {
      color: var(--error-color);
    }
    
    .message.success {
      color: var(--success-color);
    }
    
    .message i {
      margin-right: 5px;
      font-size: 1rem;
    }
    
    .btn {
      display: block;
      width: 100%;
      background: var(--primary-color);
      color: white;
      border: none;
      padding: 14px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      transition: all 0.3s;
      margin-top: 20px;
    }
    
    .btn:hover {
      background: var(--primary-hover);
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    
    .btn:active {
      transform: translateY(0);
    }
    
    .link-container {
      text-align: center;
      margin-top: 20px;
      font-size: 0.95rem;
    }
    
    .link-container a {
      color: var(--primary-color);
      text-decoration: none;
      font-weight: 600;
      transition: all 0.3s;
    }
    
    .link-container a:hover {
      color: var(--primary-hover);
      text-decoration: underline;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    @media (max-width: 576px) {
      .card-body {
        padding: 25px;
      }
      
      .card-header {
        padding: 20px;
      }
      
      .radio-group {
        flex-direction: column;
        gap: 8px;
      }
    }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
  <div class="recovery-container">
    <div class="recovery-card">
      <div class="card-header">
        <h2>Recuperação de Conta</h2>
      </div>
      
      <div class="card-body">
        <form id="recoveryForm">
          <div class="form-group">
            <label for="nomeEmpresa" class="required-field">Nome da Empresa</label>
            <div class="input-icon">
              <i class="fas fa-store"></i>
              <input type="text" id="nomeEmpresa" placeholder="Digite o nome da sua empresa" required>
            </div>
          </div>
          
          <div class="form-group">
            <label for="nif" class="required-field">NIF</label>
            <div class="input-icon">
              <i class="fas fa-id-card"></i>
              <input type="text" id="nif" placeholder="Digite o NIF da empresa" required>
            </div>
            <div id="mensagemNif" class="message"></div>
          </div>
          
          <div class="form-group">
            <label>Informe seu email ou número de celular:</label>
            <div class="radio-group">
              <div class="radio-option">
                <input type="radio" id="opcaoEmail" name="tipoRecuperacao" value="email" checked>
                <label for="opcaoEmail">Email</label>
              </div>
              <div class="radio-option">
                <input type="radio" id="opcaoCelular" name="tipoRecuperacao" value="celular">
                <label for="opcaoCelular">Celular</label>
              </div>
            </div>
            
            <div class="input-icon" id="emailGroup">
              <i class="fas fa-envelope"></i>
              <input type="email" id="email" placeholder="seu@email.com">
            </div>
            
            <div class="input-icon" id="celularGroup" style="display: none;">
              <i class="fas fa-mobile-alt"></i>
              <input type="tel" id="celular" placeholder="11987654321 (apenas números)" 
                    
              title="DDD + número (11 dígitos)">
            </div>
            <div id="mensagemContato" class="message"></div>
          </div>
          
          <button type="submit" class="btn">
            <i class="fas fa-paper-plane"></i> Enviar Código de Recuperação
          </button>
          
          <div class="link-container">
            Lembrou sua senha? <a href="i-sessao.php">Faça login</a> <br>
         <a href="../html/index.php" class="back-link">← Voltar para a página inicial</a> 
          </div>
        </form>
      </div>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Alternar entre email e celular
      const opcaoEmail = document.getElementById('opcaoEmail');
      const opcaoCelular = document.getElementById('opcaoCelular');
      const emailGroup = document.getElementById('emailGroup');
      const celularGroup = document.getElementById('celularGroup');
      
      opcaoEmail.addEventListener('change', function() {
        if (this.checked) {
          emailGroup.style.display = 'block';
          celularGroup.style.display = 'none';
          document.getElementById('mensagemContato').textContent = '';
        }
      });
      
      opcaoCelular.addEventListener('change', function() {
        if (this.checked) {
          emailGroup.style.display = 'none';
          celularGroup.style.display = 'block';
          document.getElementById('mensagemContato').textContent = '';
        }
      });
      
      // Validar NIF
      function validarNif(nif) {
        const regex = /^\d{9}$/;
        const digits = nif.replace(/\D/g, '');
        if (!regex.test(digits)) {
          return {valid: false, message: "O NIF deve conter exatamente 9 dígitos numéricos."};
        }
        return {valid: true, message: "NIF válido!"};
      }
      
      // Validar Email
      function validarEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!regex.test(email)) {
          return {valid: false, message: "Email inválido."};
        }
        return {valid: true, message: "Email válido!"};
      }
      
      // Validar Celular (apenas dígitos)
      function validarCelular(celular) {
        const digits = celular.replace(/\D/g, '');
        const regex = /^9\d{8}$/;
        if (!regex.test(digits)) {
          return {valid: false, message: "Digite 9 dígitos (244 + 9XXXXXXXX)"};
        }
        return {valid: true, message: "Número válido!"};
      }
      
      // Exibir mensagens de validação
      function exibirMensagem(idCampo, validation) {
        const elemento = document.getElementById(idCampo);
        elemento.textContent = validation.message;
        elemento.className = validation.valid ? "message success" : "message error";
        elemento.innerHTML = `<i class="fas ${validation.valid ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i> ${validation.message}`;
      }
      
      // Validação em tempo real
      document.getElementById('nif').addEventListener('input', e => {
        exibirMensagem('mensagemNif', validarNif(e.target.value));
      });
      
      document.getElementById('email').addEventListener('input', e => {
        if (opcaoEmail.checked) {
          exibirMensagem('mensagemContato', validarEmail(e.target.value.trim()));
        }
      });
      
      // Campo celular - aceita apenas números
      document.getElementById('celular').addEventListener('input', function(e) {
        // Remove qualquer caractere não numérico
        e.target.value = e.target.value.replace(/\D/g, '');
        
        if (opcaoCelular.checked) {
          exibirMensagem('mensagemContato', validarCelular(e.target.value));
        }
      });
      
      // Envio do formulário
      document.getElementById('recoveryForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const nomeEmpresa = document.getElementById('nomeEmpresa').value.trim();
        const nif = document.getElementById('nif').value;
        const usarEmail = opcaoEmail.checked;
        const email = document.getElementById('email').value.trim();
        const celular = document.getElementById('celular').value;
        
        // Validar campos obrigatórios
        if (!nomeEmpresa) {
          alert("Por favor, informe o nome da empresa.");
          return;
        }
        
        const nifValidation = validarNif(nif);
        if (!nifValidation.valid) {
          alert("Por favor, informe um NIF válido.");
          return;
        }
        
        if (usarEmail) {
          const emailValidation = validarEmail(email);
          if (!emailValidation.valid) {
            alert("Por favor, informe um email válido.");
            return;
          }
        } else {
          const celularValidation = validarCelular(celular);
          if (!celularValidation.valid) {
            alert("Por favor, informe um número de celular válido com DDD (11 dígitos).");
            return;
          }
        }
        
        // Simular envio (substitua por AJAX na implementação real)
        const dados = {
          nomeEmpresa,
          nif: nif.replace(/\D/g, ''),
          contato: usarEmail ? email : celular.replace(/\D/g, ''),
          tipoContato: usarEmail ? 'email' : 'celular'
        };
        
        console.log("Dados para envio:", dados);
        
        setTimeout(() => {
          alert("Código de recuperação enviado com sucesso!\n\nVerifique seu email/celular para continuar o processo.");
          this.reset();
          document.querySelectorAll(".message").forEach(el => el.textContent = "");
          opcaoEmail.checked = true;
          emailGroup.style.display = 'block';
          celularGroup.style.display = 'none';
        }, 500);
      });
    });
  </script>
</body>
</html>