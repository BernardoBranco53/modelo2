    document.addEventListener('DOMContentLoaded', function() {
      const form = document.getElementById('formulario');
      
      // Format phone number
      document.getElementById('celular').addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 2) {
          value = `(${value.substring(0, 2)}) ${value.substring(2)}`;
        }
        if (value.length > 10) {
          value = `${value.substring(0, 10)}-${value.substring(10, 15)}`;
        }
        e.target.value = value;
      });

      function validarNome(nome) {
        const regex = /^[A-Z][a-zA-Z_]{5,}$/;
        if (!regex.test(nome)) {
          return {valid: false, message: "O nome deve começar com maiúscula, ter no mínimo 6 letras, sem espaços ou números."};
        }
        return {valid: true, message: "Nome válido!"};
      }

      function validarNumero(numero) {
        const digits = numero.replace(/\D/g, '');
        const regex = /^\d{9}$/;
        if (!regex.test(digits)) {
          return {valid: false, message: "Deve conter exatamente 9 dígitos numéricos."};
        }
        return {valid: true, message: "Número válido!"};
      }

      function validarEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!regex.test(email)) {
          return {valid: false, message: "Email inválido."};
        }
        return {valid: true, message: "Email válido!"};
      }

      function validarSenha(senha) {
        const regex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#\$%\^&\*\(\)_\+\-=\[\]{};':"\\|,.<>\/?]).{8,18}$/;
        if (!regex.test(senha)) {
          return {valid: false, message: "Deve ter de 8 a 18 caracteres, com letras, números e símbolos."};
        }
        return {valid: true, message: "Senha forte!"};
      }

      function exibirMensagem(idCampo, validation) {
        const elemento = document.getElementById(idCampo);
        elemento.textContent = validation.message;
        elemento.className = validation.valid ? "message success" : "message error";
        
        // Adiciona ícone
        const icon = validation.valid ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-exclamation-circle"></i>';
        elemento.innerHTML = icon + ' ' + validation.message;
      }

      // Validação em tempo real
      document.getElementById('nomeEmpresa').addEventListener('input', e => {
        exibirMensagem('mensagemNome', validarNome(e.target.value.trim()));
      });

      document.getElementById('nif').addEventListener('input', e => {
        exibirMensagem('mensagemNif', validarNumero(e.target.value.trim()));
      });

      document.getElementById('celular').addEventListener('input', e => {
        exibirMensagem('mensagemCelular', validarNumero(e.target.value.replace(/\D/g, '')));
      });

      document.getElementById('email').addEventListener('input', e => {
        exibirMensagem('mensagemEmail', validarEmail(e.target.value.trim()));
      });

      document.getElementById('senha').addEventListener('input', e => {
        const senha = e.target.value;
        exibirMensagem('mensagemSenha', validarSenha(senha));

        // Verifica também a confirmação
        const confirmar = document.getElementById('confirmarSenha').value;
        if (confirmar) {
          const validation = {
            valid: confirmar === senha,
            message: confirmar === senha ? "Senhas coincidem!" : "As senhas não coincidem."
          };
          exibirMensagem('mensagemConfirmar', validation);
        }
      });

      document.getElementById('confirmarSenha').addEventListener('input', e => {
        const senha = document.getElementById('senha').value;
        const confirmar = e.target.value;
        const validation = {
          valid: confirmar === senha,
          message: confirmar === senha ? "Senhas coincidem!" : "As senhas não coincidem."
        };
        exibirMensagem('mensagemConfirmar', validation);
      });

      form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validar todos os campos
        const nomeVal = validarNome(document.getElementById('nomeEmpresa').value.trim());
        const nifVal = validarNumero(document.getElementById('nif').value.trim());
        const celVal = validarNumero(document.getElementById('celular').value.replace(/\D/g, ''));
        const emailVal = validarEmail(document.getElementById('email').value.trim());
        const senhaVal = validarSenha(document.getElementById('senha').value);
        const confirmarVal = document.getElementById('confirmarSenha').value === document.getElementById('senha').value;
        
        const abertura = document.getElementById('abertura').value;
        const fechamento = document.getElementById('fechamento').value;
        const localizacao = document.getElementById('localizacao').value.trim();
        
        // Verificar horários
        if (!abertura || !fechamento) {
          alert("Por favor, defina os horários de funcionamento.");
          return;
        }
        
        if (!localizacao) {
          alert("Por favor, informe a localização da cantina.");
          return;
        }
        
        // Exibir mensagens para campos inválidos
        if (!nomeVal.valid) exibirMensagem('mensagemNome', nomeVal);
        if (!nifVal.valid) exibirMensagem('mensagemNif', nifVal);
        if (!celVal.valid) exibirMensagem('mensagemCelular', celVal);
        if (!emailVal.valid) exibirMensagem('mensagemEmail', emailVal);
        if (!senhaVal.valid) exibirMensagem('mensagemSenha', senhaVal);
        
        const confirmValidation = {
          valid: confirmarVal,
          message: confirmarVal ? "Senhas coincidem!" : "As senhas não coincidem."
        };
        exibirMensagem('mensagemConfirmar', confirmValidation);
        
        if (nomeVal.valid && nifVal.valid && celVal.valid && 
            emailVal.valid && senhaVal.valid && confirmarVal) {
          // Simular envio (substitua por AJAX na implementação real)
          setTimeout(() => {
            alert("Cadastro realizado com sucesso!\n\nEm breve você receberá um email de confirmação.");
            form.reset();
            document.querySelectorAll(".message").forEach(el => el.textContent = "");
          }, 500);
        } else {
          // Rolagem suave para o primeiro erro
          const firstError = document.querySelector(".message.error");
          if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }
      });
    });


         // Verifica se a página atual é cadastro.php ou i-sessao.php
        if (window.location.pathname.includes('cadastro.php') || 
            window.location.pathname.includes('i-sessao.php')) {
            
            // Armazena a página atual no sessionStorage
            sessionStorage.setItem('shouldRedirectToIndex', 'true');
        }

        // Função para manipular o evento de voltar
        function handleBackButton(e) {
            if (sessionStorage.getItem('shouldRedirectToIndex') === 'true') {
                // Previne o comportamento padrão do botão voltar
                e.preventDefault();
                
                // Remove o item do sessionStorage
                sessionStorage.removeItem('shouldRedirectToIndex');
                
                // Redireciona para index.php
                window.location.href = '../html/index.php';
            }
        }

        // Adiciona o event listener para o evento popstate
        window.addEventListener('popstate', handleBackButton);

        // Adiciona um estado ao histórico para garantir que o evento popstate seja disparado
        history.pushState(null, null, window.location.href);

        // Adiciona um link de voltar manual que também usa a mesma lógica
        document.querySelector('.back-link').addEventListener('click', function(e) {
            e.preventDefault();
            sessionStorage.removeItem('shouldRedirectToIndex');
            window.location.href = '../html/index.php';
        });