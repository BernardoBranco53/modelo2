<?php
session_start();
session_destroy();
header("Location: i-sessao.php");
exit();
?>