 document.addEventListener('DOMContentLoaded', function() {
      // Função para mostrar/ocultar senha
      const togglePassword = document.getElementById('togglePassword');
      const senhaInput = document.getElementById('senha');
      
      togglePassword.addEventListener('click', function() {
        // Alternar entre type password e text
        const type = senhaInput.getAttribute('type') === 'password' ? 'text' : 'password';
        senhaInput.setAttribute('type', type);
        
        // Alternar o ícone do olho
        this.classList.toggle('fa-eye');
        this.classList.toggle('fa-eye-slash');
      });
      
      // Validação do formulário
      const form = document.querySelector('form');
      
      form.addEventListener('submit', function(e) {
        const email = document.getElementById('email').value;
        const senha = document.getElementById('senha').value;
        
        if (!email || !senha) {
          e.preventDefault();
          alert('Por favor, preencha todos os campos.');
          return;
        }
        
        // Validação simples de email
        if (!email.includes('@') || !email.includes('.')) {
          e.preventDefault();
          alert('Por favor, insira um email válido.');
          return;
        }
        
        // Validação simples de senha
        if (senha.length < 6) {
          e.preventDefault();
          alert('A senha deve ter pelo menos 6 caracteres.');
          return;
        }
      });
      
      // Efeito hover nos cards
      const cards = document.querySelectorAll('.login-card');
      cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
          card.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', () => {
          card.style.transform = 'translateY(0)';
        });
      });
    });

    