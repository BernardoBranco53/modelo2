document.addEventListener('DOMContentLoaded', function() {
    const menu = document.getElementById('mainMenu');
    const sizeIndicator = document.createElement('div');
    sizeIndicator.className = 'size-indicator';
    sizeIndicator.id = 'sizeIndicator';
    document.body.appendChild(sizeIndicator);

    // Função para sincronizar o estado do menu
    function syncMenuState() {
        const width = window.innerWidth;
        const scrollY = window.scrollY;
        
        sizeIndicator.textContent = `${width}px | ${scrollY}px`;
        
        // Remove todas as classes de estado primeiro
        menu.classList.remove('responsive', 'compact', 'scroll-compact');
        
        // Lógica para redimensionamento
        if (width <= 330) {
            menu.classList.add('responsive');
        } else if (width <= 600) {
            menu.classList.add('compact');
        }
        
        // Lógica para scroll (só aplica se não estiver no modo responsivo)
       
    }

    // Event listeners
    window.addEventListener('resize', syncMenuState);
    window.addEventListener('scroll', syncMenuState);
    
    // Inicialização
    syncMenuState();
});


function syncMenuState() {
    const width = window.innerWidth;
    const scrollY = window.scrollY;
      const searchBar = document.querySelector('.search-bar-container');
    const topFooter = document.querySelector('.top-footer');
    
    sizeIndicator.textContent = `${width}px | ${scrollY}px`;
    
    // Remove todas as classes de estado primeiro
    menu.classList.remove('responsive', 'compact', 'scroll-compact');
    topFooter.classList.remove('responsive');
    
    // Lógica para redimensionamento
    if (width <= 300) {
        menu.classList.add('responsive');
        topFooter.classList.add('responsive');
    } else if (width <= 600) {
        menu.classList.add('compact');
    }
    
    // Lógica para scroll (só aplica se não estiver no modo responsivo)
    if (scrollY > 100 && width > 300) {
        menu.classList.add('scroll-compact');
    }
}

  window.addEventListener('scroll', function () {
    const menu = document.getElementById('menu');
    if (window.scrollY > 50) {
      menu.classList.add('transparente');
    } else {
      menu.classList.remove('transparente');
    }
  });

function abribarrapesquisa(){
    const searchBar = document.querySelector('search-bar');
    searchBar.style.display =='block';
}