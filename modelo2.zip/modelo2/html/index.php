<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Responsivo com Menu Adaptável</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../css/index.css">
</head>
<body>
    <!-- Top Footer -->
        <div class="top-footer">
    <a href="../cadastro-login/i-sessao.php"><i class="fas fa-sign-in-alt"></i> <span id="remletras">Iniciar Sessão</span></a>
    <a href="../cadastro-login/cadastro.php"><i class="fas fa-user-plus"></i> <span id="remletras">Cadastre sua empresa</span></a>
</div>
    
    <!-- Menu Principal -->
    <div class="menu-container">
        <nav class="menu" id="mainMenu">
            <a href="index.html">
                <i class="fas fa-home menu-icon"></i>
                <span class="menu-text">Home</span>
            </a>
            <a href="sobre.html">
                <i class="fas fa-info-circle menu-icon"></i>
                <span class="menu-text">Sobre Nós</span>
            </a>
            <a href="servicos.html">
                <i class="fas fa-concierge-bell menu-icon"></i>
                <span class="menu-text">Serviços</span>
            </a>
            <a href="portfolio.html">
                <i class="fas fa-briefcase menu-icon"></i>
                <span class="menu-text">Portfólio</span>
            </a>
            <a href="contato.html">
                <i class="fas fa-envelope menu-icon"></i>
                <span class="menu-text">Contato</span>
            </a>
            <a href="#" id="searchToggle">
    <i class="fas fa-search menu-icon"></i>
    <span class="menu-text">Pesquisar</span>
</a>
        </nav>
    </div>
    <div class="search-bar-container">
    <div class="search-bar" onclick="abribarrapesquisa()" style="display: none;">
        <input type="text" placeholder="Pesquisar...">
        <button><i class="fas fa-search"></i></button>
    </div>
</div>
    <!-- Conteúdo -->
    <div class="main-content">
        <h1>Site Responsivo com Menu Adaptável</h1>
        <p>Redimensione a janela ou role a página para ver o menu se adaptando automaticamente.</p>
        <div style="height: 1000px;"></div>
    </div>
    
    <script src="../js/index.js"></script>
</body>
</html>