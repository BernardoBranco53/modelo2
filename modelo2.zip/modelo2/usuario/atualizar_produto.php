<?php
require '../cadastro-login/config.php';
session_start();

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($_SESSION['cliente_id'])) {
    echo json_encode(['success' => false, 'message' => 'Sessão expirada.']);
    exit;
}

if ($method === 'POST') {
    // Atualizar produto
    $stmt = $pdo->prepare("UPDATE produtos SET nomedoproduto = ?, precodoproduto = ?, quantidade = ?, descricaodoproduto = ? WHERE id = ? AND cliente_id = ?");
    $success = $stmt->execute([
        $data['nome'],
        $data['preco'],
        $data['quantidade'],
        $data['descricao'],
        $data['id'],
        $_SESSION['cliente_id']
    ]);

    if ($success) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao atualizar produto.']);
    }

} elseif ($method === 'DELETE') {
    // Remover produto
    $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = ? AND cliente_id = ?");
    $success = $stmt->execute([$data['id'], $_SESSION['cliente_id']]);

    if ($success) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao remover produto.']);
    }

} else {
    echo json_encode(['success' => false, 'message' => 'Método não suportado.']);
}
