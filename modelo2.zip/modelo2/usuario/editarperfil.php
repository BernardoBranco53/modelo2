<?php
session_start();
require '../cadastro-login/config.php';

if (!isset($_SESSION['cliente_id'])) {
    header("Location: ../cadastro-login/i-sessao.php");
    exit();
}

// Obter informações completas do cliente
$stmt = $pdo->prepare("SELECT * FROM clientes WHERE id = ?");
$stmt->execute([$_SESSION['cliente_id']]);
$cliente = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil Completo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
 <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1><?php echo htmlspecialchars($cliente['nomeempresa']); ?></h1>
    </div>
    
    <div class="main-content">
        <div class="profile-form">
            <form id="formEditarPerfil">
                <!-- Seção Informações Básicas -->
                <div class="form-section">
                    <h3><i class="fas fa-user-circle"></i> Informações Básicas</h3>
                    
                    <div class="form-group">
                        <label for="nomeEmpresa">Nome da Empresa</label>
                        <input type="text" id="nomeEmpresa" name="nomeEmpresa" 
                               value="<?php echo htmlspecialchars($cliente['nomeempresa']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" 
                               value="<?php echo htmlspecialchars($cliente['email']); ?>" required>
                        <div id="msgEmail" class="message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="celular">Celular</label>
                        <input type="tel" id="celular" name="celular" 
                               value="<?php echo htmlspecialchars($cliente['numerodecelular']); ?>" required>
                        <div id="msgCelular" class="message"></div>
                    </div>
                </div>
                
                <!-- Seção Localização -->
                <div class="form-section">
                    <h3><i class="fas fa-map-marker-alt"></i> Localização</h3>
                    
                    <div class="form-group">
                        <label for="localizacao">Endereço da Cantina</label>
                        <input type="text" id="localizacao" name="localizacao" 
                               value="<?php echo htmlspecialchars($cliente['localizacao']); ?>" required>
                    </div>
                </div>
                
                <!-- Seção Horário de Funcionamento -->
                <div class="form-section">
                    <h3><i class="fas fa-clock"></i> Horário de Funcionamento</h3>
                    
                    <div class="time-inputs">
                        <div class="form-group">
                            <label for="abertura">Abertura</label>
                            <input type="time" id="abertura" name="abertura" 
                                   value="<?php echo htmlspecialchars($cliente['horadeabertura']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="fechamento">Fechamento</label>
                            <input type="time" id="fechamento" name="fechamento" 
                                   value="<?php echo htmlspecialchars($cliente['horadefechamento']); ?>" required>
                        </div>
                    </div>
                </div>
                
                <!-- Seção Dados Financeiros -->
                <div class="form-section">
                    <h3><i class="fas fa-money-bill-wave"></i> Dados Financeiros</h3>
                    
                    <div class="form-group">
                        <label for="nif">NIF</label>
                        <input type="text" id="nif" name="nif" 
                               value="<?php echo htmlspecialchars($cliente['nif']); ?>" required>
                        <div id="msgNif" class="message"></div>
                    </div>
                </div>
                
                <!-- Seção Segurança -->
                <div class="form-section">
                    <h3><i class="fas fa-lock"></i> Segurança</h3>
                    
                    <div class="form-group">
                        <label for="senhaAtual">Senha Atual (para alterar senha)</label>
                        <input type="password" id="senhaAtual" name="senhaAtual">
                    </div>
                    
                    <div class="form-group">
                        <label for="novaSenha">Nova Senha</label>
                        <input type="password" id="novaSenha" name="novaSenha">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirmarSenha">Confirmar Nova Senha</label>
                        <input type="password" id="confirmarSenha" name="confirmarSenha">
                        <div id="msgSenha" class="message"></div>
                    </div>
                </div>
                
                <button type="submit" class="btn">
                    <i class="fas fa-save"></i> Salvar Alterações
                </button>
                <div id="msgGeral" class="message"></div>
            </form>
        </div>
    </div>
    
    <div class="footer-menu">
        <a href="painel_cliente.php" class="menu-item">
            <i class="fas fa-box"></i>
            <span>Meus Produtos</span>
        </a>
        <a href="editarproduto.php" class="menu-item">
            <i class="fas fa-edit"></i>
            <span>Editar</span>
        </a>
        <a href="perfil.php" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Perfil</span>
        </a>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Formatar celular
            document.getElementById('celular').addEventListener('input', function(e) {
                let value = e.target.value.replace(/\D/g, '');
                value = value.substring(0, 11);
                e.target.value = value;
                validarCelular(value);
            });
            
            // Formatar NIF
            document.getElementById('nif').addEventListener('input', function(e) {
                let value = e.target.value.replace(/\D/g, '');
                value = value.substring(0, 9);
                e.target.value = value;
                validarNif(value);
            });
            
            // Validar email em tempo real
            document.getElementById('email').addEventListener('input', function() {
                validarEmail(this.value);
            });
            
            // Validar senha em tempo real
            document.getElementById('novaSenha').addEventListener('input', validarSenha);
            document.getElementById('confirmarSenha').addEventListener('input', validarSenha);
            
            // Funções de validação
            function validarEmail(email) {
                const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                const valido = regex.test(email);
                const msg = document.getElementById('msgEmail');
                
                msg.textContent = valido ? 'Email válido' : 'Email inválido';
                msg.className = valido ? 'message success' : 'message error';
                
                return valido;
            }
            
            function validarCelular(celular) {
                const valido = celular.length === 9;
                const msg = document.getElementById('msgCelular');
                
                msg.textContent = valido ? 'Celular válido' : 'Deve ter 9 números';
                msg.className = valido ? 'message success' : 'message error';
                
                return valido;
            }
            
            function validarNif(nif) {
                const valido = nif.length === 9;
                const msg = document.getElementById('msgNif');
                
                msg.textContent = valido ? 'NIF válido' : 'NIF deve ter 9 dígitos';
                msg.className = valido ? 'message success' : 'message error';
                
                return valido;
            }
            
            function validarSenha() {
                const novaSenha = document.getElementById('novaSenha').value;
                const confirmarSenha = document.getElementById('confirmarSenha').value;
                const msg = document.getElementById('msgSenha');
                
                if (novaSenha === '' && confirmarSenha === '') {
                    msg.textContent = '';
                    return true;
                }
                
                if (novaSenha.length < 8) {
                    msg.textContent = 'Senha deve ter pelo menos 8 caracteres';
                    msg.className = 'message error';
                    return false;
                }
                
                if (novaSenha !== confirmarSenha) {
                    msg.textContent = 'As senhas não coincidem';
                    msg.className = 'message error';
                    return false;
                }
                
                msg.textContent = 'Senha válida';
                msg.className = 'message success';
                return true;
            }
            
            // Envio do formulário
            document.getElementById('formEditarPerfil').addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Validar campos
                const emailValido = validarEmail(document.getElementById('email').value);
                const celularValido = validarCelular(document.getElementById('celular').value);
                const nifValido = validarNif(document.getElementById('nif').value);
                const senhaValida = validarSenha();
                
                if (!emailValido || !celularValido || !nifValido) {
                    document.getElementById('msgGeral').textContent = 'Corrija os campos destacados';
                    document.getElementById('msgGeral').className = 'message error';
                    return;
                }
                
                // Verificar se senha foi alterada
                const novaSenha = document.getElementById('novaSenha').value;
                const confirmarSenha = document.getElementById('confirmarSenha').value;
                
                if ((novaSenha || confirmarSenha) && !senhaValida) {
                    document.getElementById('msgGeral').textContent = 'Corrija os campos de senha';
                    document.getElementById('msgGeral').className = 'message error';
                    return;
                }
                
                // Coletar dados do formulário
                const formData = new FormData(this);
                const dados = Object.fromEntries(formData.entries());
                
                // Enviar para o servidor
                fetch('atualizar_perfil_completo.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(dados)
                })
                .then(response => response.json())
                .then(data => {
                    const msg = document.getElementById('msgGeral');
                    msg.textContent = data.message;
                    msg.className = data.success ? 'message success' : 'message error';
                    
                    if (data.success) {
                        setTimeout(() => {
                            window.location.href = 'perfil.php';
                        }, 1500);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    document.getElementById('msgGeral').textContent = 'Erro ao processar solicitação';
                    document.getElementById('msgGeral').className = 'message error';
                });
            });
        });
    </script>
</body>
</html>