<?php
session_start();
require '../cadastro-login/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['cliente_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

try {
    // Verificar se a senha foi alterada
    if (!empty($data['novaSenha'])) {
        // Verificar senha atual
        $stmt = $pdo->prepare("SELECT senha FROM clientes WHERE id = ?");
        $stmt->execute([$_SESSION['cliente_id']]);
        $cliente = $stmt->fetch();
        
        if (!password_verify($data['senhaAtual'], $cliente['senha'])) {
            echo json_encode(['success' => false, 'message' => 'Senha atual incorreta']);
            exit();
        }
        
        // Atualizar com nova senha
        $senhaHash = password_hash($data['novaSenha'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE clientes SET 
            nomeempresa = ?, email = ?, numerodecelular = ?, localizacao = ?, 
            horadeabertura = ?, horadefechamento = ?, nif = ?, senha = ?
            WHERE id = ?");
        
        $stmt->execute([
            $data['nomeEmpresa'],
            $data['email'],
            $data['celular'],
            $data['localizacao'],
            $data['abertura'],
            $data['fechamento'],
            $data['nif'],
            $senhaHash,
            $_SESSION['cliente_id']
        ]);
    } else {
        // Atualizar sem alterar senha
        $stmt = $pdo->prepare("UPDATE clientes SET 
            nomeempresa = ?, email = ?, numerodecelular = ?, localizacao = ?, 
            horadeabertura = ?, horadefechamento = ?, nif = ?
            WHERE id = ?");
        
        $stmt->execute([
            $data['nomeEmpresa'],
            $data['email'],
            $data['celular'],
            $data['localizacao'],
            $data['abertura'],
            $data['fechamento'],
            $data['nif'],
            $_SESSION['cliente_id']
        ]);
    }
    
    echo json_encode(['success' => true, 'message' => 'Perfil atualizado com sucesso!']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao atualizar perfil: ' . $e->getMessage()]);
}
?>