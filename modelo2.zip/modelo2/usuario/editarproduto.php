<?php
session_start();
require '../cadastro-login/config.php';

if (!isset($_SESSION['cliente_id'])) {
    header("Location: ../cadastro-login/i-sessao.php");
    exit();
}

// Obter informações do cliente
$stmt = $pdo->prepare("SELECT nomeempresa FROM clientes WHERE id = ?");
$stmt->execute([$_SESSION['cliente_id']]);
$cliente = $stmt->fetch();

// Obter produtos do cliente
$stmt = $pdo->prepare("SELECT * FROM produtos WHERE cliente_id = ?");
$stmt->execute([$_SESSION['cliente_id']]);
$produtos = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produtos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Manter os mesmos estilos do painel_cliente.php */
        /* Adicionar estilos específicos para a tabela de edição */
        .product-list {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .product-list th, .product-list td {
            border: 1px solid var(--border-color);
            padding: 10px;
            text-align: left;
        }
        
        .product-list input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        
        .action-btn {
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin: 0 5px;
        }
        
        .update-btn {
            background-color: var(--primary-color);
            color: white;
        }
        
        .delete-btn {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo htmlspecialchars($cliente['nomeempresa']); ?></h1>
    </div>
    
    <div class="main-content">
        <table class="product-list">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Preço</th>
                    <th>Quantidade</th>
                    <th>Descrição</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produtos as $produto): ?>
                <tr>
                    <td><input type="text" name="nome" value="<?php echo htmlspecialchars($produto['nome']); ?>"></td>
                    <td><input type="number" step="0.01" name="preco" value="<?php echo $produto['preco']; ?>"></td>
                    <td><input type="number" name="quantidade" value="<?php echo $produto['quantidade']; ?>"></td>
                    <td><input type="text" name="descricao" value="<?php echo htmlspecialchars($produto['descricao']); ?>"></td>
                    <td>
                        <button class="action-btn update-btn" onclick="atualizarProduto(<?php echo $produto['id']; ?>, this)">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                        <button class="action-btn delete-btn" onclick="removerProduto(<?php echo $produto['id']; ?>)">
                            <i class="fas fa-times"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <div class="footer-menu">
        <a href="painel_cliente.php" class="menu-item">
            <i class="fas fa-box"></i>
            <span>Meus Produtos</span>
        </a>
        <a href="editarproduto.php" class="menu-item">
            <i class="fas fa-edit"></i>
            <span>Editar</span>
        </a>
        <a href="perfil.php" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Perfil</span>
        </a>
    </div>

    <script>
        function atualizarProduto(id, btn) {
            const row = btn.closest('tr');
            const dados = {
                id: id,
                nome: row.querySelector('input[name="nome"]').value,
                preco: row.querySelector('input[name="preco"]').value,
                quantidade: row.querySelector('input[name="quantidade"]').value,
                descricao: row.querySelector('input[name="descricao"]').value
            };
            
            fetch('atualizar_produto.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(dados)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Produto atualizado com sucesso!');
                } else {
                    alert('Erro ao atualizar: ' + data.message);
                }
            });
        }
        
        function removerProduto(id) {
            if (confirm('Tem certeza que deseja remover este produto?')) {
                fetch('atualizar_produto.php', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ id: id })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Produto removido com sucesso!');
                        location.reload();
                    } else {
                        alert('Erro ao remover: ' + data.message);
                    }
                });
            }
        }
    </script>
</body>
</html>