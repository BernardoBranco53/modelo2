<?php
session_start();
require '../cadastro-login/config.php';

if (!isset($_SESSION['cliente_id'])) {
    header("Location: ../cadastro-login/i-sessao.php");
    exit();
}

// Obter informações do cliente
$stmt = $pdo->prepare("SELECT * FROM clientes WHERE id = ?");
$stmt->execute([$_SESSION['cliente_id']]);
$cliente = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Manter os mesmos estilos do painel_cliente.php */
        .profile-form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
        }
        
        .save-btn {
            background-color: var(--primary-color);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo htmlspecialchars($cliente['nomeempresa']); ?></h1>
    </div>
    
    <div class="main-content">
        <div class="profile-form">
            <div class="form-group">
                <label for="nomeEmpresa">Nome da Empresa</label>
                <input type="text" id="nomeEmpresa" value="<?php echo htmlspecialchars($cliente['nomeempresa']); ?>">
            </div>
            
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" value="<?php echo htmlspecialchars($cliente['email']); ?>">
            </div>
            
            <div class="form-group">
                <label for="celular">Celular</label>
                <input type="tel" id="celular" value="<?php echo htmlspecialchars($cliente['numerodecelular']); ?>">
            </div>
            
            <div class="form-group">
                <label for="localizacao">Localização</label>
                <input type="text" id="localizacao" value="<?php echo htmlspecialchars($cliente['localizacao']); ?>">
            </div>
            
            <button class="save-btn" onclick="atualizarPerfil()">
                <i class="fas fa-save"></i> Salvar Alterações
            </button>
            
            <a href="editarperfil.php" style="display: block; margin-top: 20px;">
                <i class="fas fa-user-edit"></i> Editar informações adicionais
            </a>
           
            <a href="../cadastro-login/logout.php" style="display: block; margin-top: 20px;">
                <i class=""></i> Terminar sessão
            </a>


        </div>
    </div>
    
    <div class="footer-menu">
        <a href="painel_cliente.php" class="menu-item">
            <i class="fas fa-box"></i>
            <span>Meus Produtos</span>
        </a>
        <a href="editarproduto.php" class="menu-item">
            <i class="fas fa-edit"></i>
            <span>Editar</span>
        </a>
        <a href="perfil.php" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Perfil</span>
        </a>
    </div>

    <script>
        function atualizarPerfil() {
            const dados = {
                nomeEmpresa: document.getElementById('nomeEmpresa').value,
                email: document.getElementById('email').value,
                celular: document.getElementById('celular').value,
                localizacao: document.getElementById('localizacao').value
            };
            
            fetch('atualizar_perfil.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(dados)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Perfil atualizado com sucesso!');
                } else {
                    alert('Erro ao atualizar: ' + data.message);
                }
            });
        }
    </script>
</body>
</html>