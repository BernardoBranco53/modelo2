<?php
session_start();
require '../cadastro-login/config.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['cliente_id'])) {
    header("Location: ../cadastro-login/i-sessao.php");
    exit();
}

// Obter informações do cliente
$stmt = $pdo->prepare("SELECT * FROM clientes WHERE id = ?");
$stmt->execute([$_SESSION['cliente_id']]);
$cliente = $stmt->fetch();

// Se não encontrar cliente, destrói a sessão e redireciona
if (!$cliente) {
    session_destroy();
    header("Location: ../cadastro-login/i-sessao.php");
    exit();
}

// Processar remoção de produto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remover_produto'])) {
    $produto_id = $_POST['produto_id'];
    
    // Primeiro obtém o nome da imagem para deletar do servidor
    $stmt = $pdo->prepare("SELECT imagemdoproduto FROM produtos WHERE id = ? AND cliente_id = ?");
    $stmt->execute([$produto_id, $_SESSION['cliente_id']]);
    $produto = $stmt->fetch();
    
    if ($produto) {
        // Remove o produto do banco de dados
        $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = ? AND cliente_id = ?");
        $stmt->execute([$produto_id, $_SESSION['cliente_id']]);
        
        // Remove a imagem associada se existir
        if (!empty($produto['imagemdoproduto']) && file_exists("../uploads/" . $produto['imagemdoproduto'])) {
            unlink("../uploads/" . $produto['imagemdoproduto']);
        }
        
        // Recarrega a página para atualizar a lista
        header("Location: painel_cliente.php");
        exit();
    }
}

// Obter produtos do cliente
$stmt = $pdo->prepare("SELECT * FROM produtos WHERE cliente_id = ? ORDER BY data_cadastro DESC");
$stmt->execute([$_SESSION['cliente_id']]);
$produtos = $stmt->fetchAll();

// Contar produtos cadastrados
$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM produtos WHERE cliente_id = ?");
$stmt->execute([$_SESSION['cliente_id']]);
$total_produtos = $stmt->fetch()['total'];

// Calcular valor total do estoque
$stmt = $pdo->prepare("SELECT SUM(precodoproduto * quantidade) as total_estoque FROM produtos WHERE cliente_id = ?");
$stmt->execute([$_SESSION['cliente_id']]);
$valor_estoque = $stmt->fetch()['total_estoque'];
$valor_exibicao = $valor_estoque ? number_format($valor_estoque, 2, ',', '.') : '0,00';
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Cliente - <?= htmlspecialchars($cliente['nomeempresa']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #077aa8;
            --primary-hover: #54d1e7;
            --secondary-color: #6c757d;
            --light-gray: #f8f9fa;
            --border-color: #ced4da;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --success-color: #28a745;
            --error-color: #dc3545;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f5f5f5;
        }
        
        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 20px;
            text-align: center;
        }
        
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            padding: 20px;
            background-color: var(--light-gray);
            max-width: 1200px;
            margin: 0 auto;
            width: 95%;
        }
        
        .stat-card {
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: var(--box-shadow);
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
        }
        
        .stat-card h3 {
            margin-top: 0;
            color: var(--secondary-color);
            font-size: 1.1rem;
        }
        
        .stat-card .value {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .stat-card .value.success {
            color: var(--success-color);
        }
        
        .stat-card a {
            text-decoration: none;
            color: inherit;
            display: block;
            height: 100%;
        }
        
        .main-content {
            flex: 1;
            padding: 20px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
            width: 95%;
        }
        
        .product-card {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 15px;
            box-shadow: var(--box-shadow);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            background: white;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        
        .product-card h3 {
            margin-top: 10px;
            margin-bottom: 5px;
            color: var(--primary-color);
            font-size: 1.2rem;
        }
        
        .product-image-container {
            position: relative;
            width: 100%;
            height: 180px;
            overflow: hidden;
            border-radius: 5px;
            margin-bottom: 10px;
            background-color: #f5f5f5;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .product-image {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            transition: transform 0.3s ease;
        }
        
        .product-card:hover .product-image {
            transform: scale(1.05);
        }
        
        .no-image {
            font-size: 3rem;
            color: var(--secondary-color);
            opacity: 0.3;
        }
        
        .availability-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: bold;
            color: white;
            z-index: 1;
        }
        
        .available {
            background-color: var(--success-color);
        }
        
        .unavailable {
            background-color: var(--error-color);
        }
        
        .product-info {
            margin-top: 10px;
        }
        
        .product-info p {
            margin: 5px 0;
            font-size: 0.9rem;
        }
        
        .product-info strong {
            color: var(--secondary-color);
        }
        
        .product-description {
            font-size: 0.85rem;
            color: #555;
            margin-top: 10px;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .product-date {
            font-size: 0.8rem;
            color: var(--secondary-color);
            margin-top: 10px;
        }
        
        .footer-menu {
            background-color: var(--primary-color);
            display: flex;
            justify-content: space-around;
            padding: 15px 0;
            position: sticky;
            bottom: 0;
        }
        
        .menu-item {
            color: white;
            text-decoration: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 0.9rem;
        }
        
        .menu-item i {
            font-size: 1.5rem;
            margin-bottom: 5px;
        }
        
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 40px;
            color: var(--secondary-color);
        }
        
        .add-product-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
        }
        
        .add-product-btn i {
            font-size: 2rem;
            margin-bottom: 10px;
            color: var(--primary-color);
        }
        
        .delete-btn {
            position: absolute;
            top: 10px;
            left: 10px;
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background-color: var(--error-color);
            color: white;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 2;
            opacity: 0;
            transition: all 0.3s ease;
        }
        
        .product-card:hover .delete-btn {
            opacity: 1;
        }
        
        .delete-btn:hover {
            background-color: #c82333;
            transform: scale(1.1);
        }
        
        .delete-form {
            display: inline;
        }
        
        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            }
            
            .dashboard-stats {
                grid-template-columns: 1fr;
            }
            
            .product-card h3 {
                font-size: 1.1rem;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?= htmlspecialchars($cliente['nomeempresa']) ?></h1>
        <p>Bem-vindo ao seu painel de controle</p>
    </div>
    
    <div class="dashboard-stats">
        <div class="stat-card">
            <h3>Produtos Cadastrados</h3>
            <div class="value"><?= $total_produtos ?></div>
        </div>
        <div class="stat-card">
            <h3>Valor em Estoque</h3>
            <div class="value success">Kzs <?= $valor_exibicao ?></div>
        </div>
        <div class="stat-card">
            <a href="adicionar_produto.php">
                <div class="add-product-btn">
                    <i class="fas fa-plus-circle"></i>
                    <h3>Adicionar Produto</h3>
                </div>
            </a>
        </div>
    </div>
    
    <div class="main-content">
        <?php if (count($produtos) > 0): ?>
            <?php foreach ($produtos as $produto): ?>
                <div class="product-card">
                    <!-- Botão de deletar -->
                    <form class="delete-form" method="POST" onsubmit="return confirm('Tem certeza que deseja remover este produto?')">
                        <input type="hidden" name="produto_id" value="<?= $produto['id'] ?>">
                        <button type="submit" name="remover_produto" class="delete-btn" title="Remover produto">
                            <i class="fas fa-times"></i>
                        </button>
                    </form>
                    
                    <div class="product-image-container">
                        <?php if (!empty($produto['imagemdoproduto'])): ?>
                            <img src="../uploads/<?= htmlspecialchars($produto['imagemdoproduto']) ?>" 
                                 alt="<?= htmlspecialchars($produto['nomedoproduto']) ?>" 
                                 class="product-image"
                                 onerror="this.style.display='none';this.parentNode.innerHTML='<i class=\"fas fa-box-open no-image\"></i>'">
                        <?php else: ?>
                            <i class="fas fa-box-open no-image"></i>
                        <?php endif; ?>
                    </div>
                    
                    <div class="availability-badge <?= $produto['quantidade'] > 0 ? 'available' : 'unavailable' ?>">
                        <?= $produto['quantidade'] > 0 ? 'Disponível' : 'Esgotado' ?>
                    </div>
                    
                    <h3><?= htmlspecialchars($produto['nomedoproduto']) ?></h3>
                    
                    <div class="product-info">
                        <p><strong>Preço:</strong> Kzs <?= number_format($produto['precodoproduto'], 2, ',', '.') ?></p>
                        <p><strong>Quantidade:</strong> <?= $produto['quantidade'] ?></p>
                    </div>
                    
                    <?php if (!empty($produto['descricao'])): ?>
                        <p class="product-description"><?= htmlspecialchars($produto['descricao']) ?></p>
                    <?php endif; ?>
                    
                    <p class="product-date"><small>Cadastrado em: <?= date('d/m/Y', strtotime($produto['data_cadastro'])) ?></small></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-box-open" style="font-size: 3rem; margin-bottom: 15px;"></i>
                <h3>Nenhum produto cadastrado</h3>
                <p>Você ainda não cadastrou nenhum produto em sua cantina.</p>
                <a href="adicionar_produto.php" style="color: var(--primary-color); font-weight: bold;">Adicionar primeiro produto</a>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="footer-menu">
        <a href="painel_cliente.php" class="menu-item">
            <i class="fas fa-home"></i>
            <span>Início</span>
        </a>
        <a href="editarproduto.php" class="menu-item">
            <i class="fas fa-edit"></i>
            <span>Editar</span>
        </a>
        <a href="perfil.php" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Perfil</span>
        </a>
    </div>

    <script>
        // Adiciona confirmação antes de deletar
        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                if (!confirm('Tem certeza que deseja remover este produto permanentemente?')) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>