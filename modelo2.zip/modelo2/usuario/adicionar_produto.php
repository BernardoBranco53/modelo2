<?php
session_start();
require '../cadastro-login/config.php';

if (!isset($_SESSION['cliente_id'])) {
    header("Location: ../cadastro-login/i-sessao.php");
    exit();
}

// Obter informações do cliente
$stmt = $pdo->prepare("SELECT nomeempresa FROM clientes WHERE id = ?");
$stmt->execute([$_SESSION['cliente_id']]);
$cliente = $stmt->fetch();



// Processar o formulário quando enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $nome = $_POST['nome'];
        $preco = $_POST['preco'];
        $quantidade = $_POST['quantidade'];
        $descricao = $_POST['descricao'] ?? '';
        
        // Processar upload de imagem
        $imagemNome = null;
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            $extensao = pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION);
            $imagemNome = uniqid() . '.' . $extensao;
            move_uploaded_file($_FILES['imagem']['tmp_name'], "../uploads/" . $imagemNome);
        }
        
        // Inserir produto no banco de dados
        $stmt = $pdo->prepare("INSERT INTO produtos 
                              (nomedoproduto, precodoproduto, quantidade, descricaodoproduto, cliente_id, imagemdoproduto, data_cadastro) 
                              VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            $nome,
            $preco,
            $quantidade,
            $descricao,
            $_SESSION['cliente_id'],
            $imagemNome
        ]);
        
        $mensagem = "Produto adicionado com sucesso!";
        $tipoMensagem = "success";
    } catch (PDOException $e) {
        $mensagem = "Erro ao adicionar produto: " . $e->getMessage();
        $tipoMensagem = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Produto - <?= htmlspecialchars($cliente['nomeempresa']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: var(--box-shadow);
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .form-group input, 
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid var(--border-color);
            border-radius: 6px;
        }
        
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .btn-submit {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        .btn-submit:hover {
            background-color: var(--primary-hover);
        }
        
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .message.success {
            background-color: rgba(40, 167, 69, 0.2);
            color: var(--success-color);
        }
        
        .message.error {
            background-color: rgba(220, 53, 69, 0.2);
            color: var(--error-color);
        }
        
        .preview-imagem {
            max-width: 200px;
            max-height: 200px;
            margin-top: 10px;
            display: none;
        }
        .btn-submit  {
      margin-left: 18%;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?= htmlspecialchars($cliente['nomeempresa']) ?></h1>
        <p>Adicionar Novo Produto</p>
    </div>
    
    <div class="form-container">
        <?php if (isset($mensagem)): ?>
            <div class="message <?= $tipoMensagem ?>"><?= $mensagem ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="nome">Nome do Produto *</label>
                <input type="text" id="nome" name="nome" required>
            </div>
            
            <div class="form-group">
                <label for="preco">Preço (Kzs) *</label>
                <input type="number" id="preco" name="preco" step="0.01" min="0" required>
            </div>
            
            <div class="form-group">
                <label for="quantidade">Quantidade em Estoque *</label>
                <input type="number" id="quantidade" name="quantidade" min="0" required>
            </div>
            
            <div class="form-group">
                <label for="descricao">Descrição</label>
                <textarea id="descricao" name="descricao"></textarea>
            </div>
            
            <div class="form-group">
                <label for="imagem">Imagem do Produto</label>
                <input type="file" id="imagem" name="imagem" accept="image/*">
                <img id="preview" class="preview-imagem" src="#" alt="Pré-visualização da imagem">
            </div>
            
            <button type="submit" class="btn-submit">
                <i class="fas fa-save"></i> Adicionar Produto
            </button>
        </form>
    </div>
    
    <div class="footer-menu">
        <a href="painel_cliente.php" class="menu-item">
            <i class="fas fa-box"></i>
            <span>Meus Produtos</span>
        </a>
        <a href="editarproduto.php" class="menu-item">
            <i class="fas fa-edit"></i>
            <span>Editar</span>
        </a>
        <a href="perfil.php" class="menu-item">
            <i class="fas fa-user"></i>
            <span>Perfil</span>
        </a>
    </div>

    <script>
        // Pré-visualização da imagem
        document.getElementById('imagem').addEventListener('change', function(e) {
            const preview = document.getElementById('preview');
            const file = e.target.files[0];
            
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
            }
        });
        
        // Validação básica do formulário
        document.querySelector('form').addEventListener('submit', function(e) {
            const preco = document.getElementById('preco').value;
            const quantidade = document.getElementById('quantidade').value;
            
            if (preco <= 0) {
                alert('O preço deve ser maior que zero');
                e.preventDefault();
                return;
            }
            
            if (quantidade < 0) {
                alert('A quantidade não pode ser negativa');
                e.preventDefault();
            }
        });
        // validar arquivo de imagem
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
if (!in_array($_FILES['imagem']['type'], $allowedTypes)) {
    die("Tipo de arquivo não permitido");
}

// tamanho máximo do arquivo
$maxSize = 2 * 1024 * 1024; // 2MB
if ($_FILES['imagem']['size'] > $maxSize) {
    die("O arquivo é muito grande (máximo 2MB)");
}
    </script>
</body>
</html>